import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TkiezView",
  description: "Organiseur perso/pro + Trading (Objectifs, Journal, Stats).",
  themeColor: "#ffffff",
  icons: { icon: "/icons/favicon.ico" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="theme-color" content="#ffffff" />
      </head>
      <body>{children}</body>
    </html>
  );
}
